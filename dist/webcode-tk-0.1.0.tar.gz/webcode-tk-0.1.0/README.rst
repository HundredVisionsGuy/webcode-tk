webcode-toolkit (webcode-tk)
============================

A set of tools for inspecting HTML and CSS code for validity and other
various checks, such as semantics or required elements.
